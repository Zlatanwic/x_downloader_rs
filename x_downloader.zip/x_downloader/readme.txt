还需要你有x账号且保持登录状态，使用“Get cookies.txt LOCALLY”浏览器插件，导出txt文件，并且改名为cookies.txt放到统一目录
用法：linux系统命令行输入
x_downloader_rs "你想要的x帖子的url"